# My Django Rating App
